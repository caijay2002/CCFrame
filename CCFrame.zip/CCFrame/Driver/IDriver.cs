﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


#region << 驱动接口 >>
/*----------------------------------------------------------------
// 文件名称：IDriver
// 创 建 者：蔡程健
// 创建时间：22/5/26 17:02:11
// 文件版本：
// ===============================================================
// 功能描述：
//		
//
//----------------------------------------------------------------*/
#endregion

namespace CCFrame.Driver
{
    public interface IDriver
    {
    }
}
