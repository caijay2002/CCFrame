﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


#region << 文 件 说 明 >>
/*----------------------------------------------------------------
// 文件名称：StringResources
// 创 建 者：蔡程健
// 创建时间：22/5/23 15:00:20
// 文件版本：
// ===============================================================
// 功能描述：
//		
//
//----------------------------------------------------------------*/
#endregion

namespace CCFrame.Language
{
    public static class StringResources
    {
        public static DefaultLanguage Language = new DefaultLanguage();
    }
}
